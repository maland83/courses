-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.6.37 - MySQL Community Server (GPL)
-- Операционная система:         Win32
-- HeidiSQL Версия:              9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица courses.cores
DROP TABLE IF EXISTS `cores`;
CREATE TABLE IF NOT EXISTS `cores` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `cores` tinyint(4) DEFAULT NULL,
  `frequency` decimal(10,0) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Дамп данных таблицы courses.cores: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `cores` DISABLE KEYS */;
REPLACE INTO `cores` (`id`, `model`, `cores`, `frequency`) VALUES
	(1, 'Intel Atom x5-Z8350', 2, 2),
	(2, 'Intel Core i7-7500U', 2, 2),
	(3, 'Intel Celeron N3350', 2, 3),
	(4, 'Intel Pentium 4405U', 5, 3);
/*!40000 ALTER TABLE `cores` ENABLE KEYS */;

-- Дамп структуры для таблица courses.orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned zerofill NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_orders_products` (`product_id`),
  CONSTRAINT `FK_orders_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

-- Дамп данных таблицы courses.orders: ~12 rows (приблизительно)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
REPLACE INTO `orders` (`id`, `product_id`, `order_date`) VALUES
	(1, 00000000015, '2018-03-13 19:05:04'),
	(2, 00000000016, '2018-03-13 19:05:14'),
	(3, 00000000016, '2018-03-13 19:05:14'),
	(4, 00000000002, '2018-03-13 19:06:00'),
	(5, 00000000002, '2018-03-13 19:06:00'),
	(6, 00000000025, '2018-03-13 19:07:46'),
	(7, 00000000033, '2018-03-13 19:07:53'),
	(8, 00000000023, '2018-03-13 19:07:59'),
	(9, 00000000009, '2018-03-13 19:08:05'),
	(10, 00000000027, '2018-03-13 19:08:09'),
	(11, 00000000027, '2018-03-13 19:08:09'),
	(12, 00000000027, '2018-03-13 19:08:09'),
	(13, 00000000027, '2018-03-13 19:08:09');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Дамп структуры для таблица courses.products
DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` float unsigned NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Индекс 2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

-- Дамп данных таблицы courses.products: ~35 rows (приблизительно)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
REPLACE INTO `products` (`id`, `name`, `description`, `price`, `created`, `updated`, `type`) VALUES
	(1, 'Pixus Vision 10.1 3G', 'Экран 10.1" IPS (1920x1200) MultiTouch / MediaTek MT6753 (1.3 ГГц) / RAM 2 ГБ / 16 ГБ встроенной памяти + microSD / 3G / LTE / Wi-Fi / Bluetooth 4.0 / основная камера 5 Мп, фронтальная - 2 Мп / GPS / A-GPS / поддержка 2-х СИМ-карт / Android 7.0 (Nougat) / 450 г / черный', 3999, '2018-03-10 08:43:06', '2018-03-10 08:43:06', 'Планшет'),
	(2, 'Samsung Galaxy Tab E 9.6" 3G Black (SM-T561NZKASEK)', 'Экран 9.6" (1280x800) емкостный MultiTouch / T-Shark2 (1.3 ГГц) / RAM 1.5 ГБ / 8 ГБ встроенной памяти + microSD / 3G / Wi-Fi 802.11a/b/g/n / Bluetooth 4.0 / основная камера 5 Мп, фронтальная 2 Мп / GPS / ГЛОНАСС / Android 4.4 (KitKat) / 490 г / черный', 4999, '2018-03-10 08:44:20', '2018-03-10 08:44:20', 'Планшет '),
	(3, 'Asus ZenPad 10 2/16GB LTE Dark Gray (Z301MFL-1H011A)', 'Экран 10.1" IPS (1920x1080) емкостный MultiTouch / MediaTek MT8735А (1.45 ГГц) / RAM 2 ГБ / 16 ГБ встроенной памяти + microSD / 3G / LTE / Wi-Fi 802.11 a/b/g/n / Bluetooth 4.1 / основная камера 5 Мп, фронтальная - 2 Мп / GPS / ГЛОНАСС / ОС Android 6.0 / 490 г / темно-серый', 6499, '2018-03-10 08:45:27', '2018-03-10 08:45:27', 'Планшет'),
	(4, 'Mystery MID-703G', 'Экран 7" (800х480) емкостный, MultiTouch / Mediatek MT8312 (1.3 ГГц) / RAM 512 МБ / 4 ГБ встроенной памяти + microSD / Wi-Fi / Bluetooth / основная камера 2 Мп, фронтальная 0.3 Мп / 3G / GPS / Android 4.2 (Jelly Bean)', 1349, '2018-03-10 08:46:26', '2018-03-10 08:46:36', 'Планшет'),
	(5, 'Lenovo K6 Note (K53a48) Grey', 'Экран (5.5", IPS, 1920x1080)/ Qualcomm Snapdragon 430 (1.4 ГГц)/ основная камера: 16 Мп, фронтальная камера: 8 Мп/ RAM 3 ГБ/ 32 ГБ встроенной памяти + microSD/SDHC (до 128 ГБ)/ 3G/ LTE/ GPS/ поддержка 2х SIM-карт (Nano-SIM)/ Android 6.0 (Marshmallow) / 4000 мА*ч', 6495, '2018-03-10 08:48:12', '2018-03-10 08:48:13', 'Мобильные телефоны'),
	(6, 'Prestigio Grace R5 5552 LTE Gold', 'Экран (5.5", IPS, 1280x720)/ MediaTek MT6737 (1.3 ГГц)/ основная камера: 13 Мп, фронтальная камера: 2 Мп/ RAM 1 ГБ/ 16 ГБ встроенной памяти + microSD/SDHC (до 32 ГБ)/ 3G/ GPS/ поддержка 2х SIM-карт (Micro-SIM)/ Android 7.0 (Nougat) / 3000 мА*ч', 2599, '2018-03-10 08:48:12', '2018-03-10 08:48:13', 'Мобильные телефоны'),
	(7, 'Samsung Galaxy J3 2016 J320H/DS Black', 'Экран (5", Super AMOLED, 1280x720)/ четырёхъядерный (1.3 ГГц)/ основная камера: 8 Мп, фронтальная камера: 5 Мп/ RAM 1.5 ГБ/ 8 ГБ встроенной памяти + microSD (до 128 ГБ)/ 3G/ GPS/ поддержка 2х SIM-карт (Micro-SIM + Micro-SIM)/ Android 5.1 Lollipop / 2600 мА*ч', 2999, '2018-03-10 08:48:12', '2018-03-10 08:48:13', 'Мобильные телефоны'),
	(8, 'LG Q6 Prime 3/32GB Black', 'Экран (5.5", IPS, 2160x1080)/ Qualcomm Snapdragon 435 (1.4 ГГц)/ основная камера: 13 Мп, фронтальная камера: 5 Мп/ RAM 3 ГБ/ 32 ГБ встроенной памяти +microSD/SDHC (до 2 ТБ)/ 3G/ LTE/ GPS/ поддержка 2х SIM-карт (Nano-SIM)/Android 7.0 (Nougat) / 3000 мА*ч', 6499, '2018-03-10 08:48:12', '2018-03-10 08:48:13', 'Мобильные телефоны'),
	(9, 'TP-LINK Neffos X1 Lite Gold ', 'Экран (5", IPS, 1280x720)/ MediaTek MT6750 (1.5 ГГц + 1.0 ГГц) / основная камера: 13 Мп, фронтальная камера: 5 Мп/ RAM 2 ГБ/ 16 ГБ встроенной памяти + microSD (до 128 ГБ)/ 3G/ LTE/ GPS/ поддержка 2х SIM-карт (Nano-SIM)/ Android 7.0 (Nougat) / 2550 мА*ч', 2999, '2018-03-10 08:48:12', '2018-03-10 08:48:13', 'Мобильные телефоны'),
	(10, 'Samsung Galaxy Note 8 64GB Orchid Gray', 'Экран (6.3", Super AMOLED, 2960х1440)/ Samsung Exynos 8895 (Quad 2.3 ГГц + Quad 1.7 ГГц)/ камера 12 Мп+12 Мп + фронтальная 8 Мп/ RAM 6 ГБ/ 64 ГБ встроенной памяти + microSD (до 256 ГБ)/ 3G/ LTE/ GPS/ поддержка 2х SIM-карт (Nano-SIM)/ Android 7.1.1 (Nougat) / 3300 мА*ч', 29999, '2018-03-10 08:48:12', '2018-03-10 08:48:13', 'Мобильные телефоны'),
	(11, 'Samsung Galaxy J3 2016 J320H/DS Black', 'Экран (5", Super AMOLED, 1280x720)/ четырёхъядерный (1.3 ГГц)/ основная камера: 8 Мп, фронтальная камера: 5 Мп/ RAM 1.5 ГБ/ 8 ГБ встроенной памяти + microSD (до 128 ГБ)/ 3G/ GPS/ поддержка 2х SIM-карт (Micro-SIM + Micro-SIM)/ Android 5.1 Lollipop / 2600 мА*ч', 2999, '2018-03-10 08:53:39', '2018-03-10 08:53:39', 'Мобильные телефоны'),
	(12, 'Samsung Galaxy A7 2017 Duos SM-A720 Gold', 'Экран (5.7", Super AMOLED, 1920x1080)/ Samsung Exynos 7880 (1.9 ГГц)/ основная камера: 16 Мп, фронтальная камера: 16 Мп/ RAM 3 ГБ/ 32 ГБ встроенной памяти + microSD/SDHC (до 256 ГБ)/ 3G/ LTE/ GPS/ поддержка 2х SIM-карт (Nano-SIM)/ Android 6.0 (Marshmallow)/ 3600 мА*ч', 11499, '2018-03-10 08:54:31', '2018-03-10 08:54:36', 'Мобильные телефоны'),
	(13, 'Samsung Galaxy A8+ 2018 4/32GB Orchid Gray', 'Экран (6.0", Super AMOLED, 1080x2220)/ Samsung Exynos 7885 (2.2 ГГц + 1.6 ГГц)/ основная камера: 16 Мп, фронтальная камера: 16 Мп + 8 Мп/ RAM 4 ГБ/ 32 ГБ встроенной памяти + microSD/SDHC (до 256 ГБ)/ 3G/ LTE/ GPS/ ГЛОНАСС/ поддержка 2х SIM-карт (Nano-SIM)/ Android 7.1.1 (Nougat)/ 3500 мА*ч', 16999, '2018-03-10 08:55:23', '2018-03-10 08:55:23', 'Мобильные телефоны'),
	(14, 'Apple iPhone 6s 32GB Rose Gold', 'Экран (4.7", IPS, 1334x750)/ Apple A9 (1.8 ГГц)/ основная камера: 12 Мп, фронтальная камера: 5 Мп/ RAM 2 ГБ/ 32 ГБ встроенной памяти/ 3G/ LTE/ GPS/ Nano-SIM/ iOS 9/', 14999, '2018-03-10 08:57:40', '2018-03-10 08:57:40', 'Мобильные телефоны'),
	(15, 'Apple iPhone 6 32GB Space Gray', 'Экран (4.7", IPS, 1334x750)/ Apple A8 (1.4 ГГц)/ основная камера: 8 Мп, фронтальная камера: 1.2 Мп/ RAM 1 ГБ/ 32 ГБ встроенной памяти/ 3G/ LTE/ GPS/ Nano-SIM/ iOS 8/ 1810 мА*ч', 10999, '2018-03-10 08:58:25', '2018-03-10 08:58:28', 'Мобильные телефоны'),
	(16, 'Apple iPhone X 64GB Silver', 'Экран (5.8", OLED (Super Retina HD), 2436x1125)/ Apple A11 Bionic/ основная камера: двойная 12 Мп, фронтальная камера: 7 Мп/ RAM 3 ГБ/ 64 ГБ встроенной памяти/ 3G/ LTE/ GPS/ Nano-SIM/ iOS 11', 34999, '2018-03-10 08:59:20', '2018-03-10 08:59:20', 'Мобильные телефоны'),
	(17, 'Apple iPhone 7 32GB Jet Black', 'Экран (4.7", IPS, 1334x750)/ Apple A10 Fusion/ основная камера: 12 Мп, фронтальная камера: 7 Мп/ RAM 2 ГБ/ 32 ГБ встроенной памяти/ 3G/ LTE/ GPS/ Nano-SIM/ iOS', 17999, '2018-03-10 09:00:22', '2018-03-10 09:00:23', 'Мобильные телефоны'),
	(18, 'Apple iPhone 7 Plus 128GB Rose Gold', 'Экран (5.5", IPS, 1920x1080)/ Apple A10 Fusion/ основная камера: двойная 12 Мп, фронтальная камера: 7 Мп/ RAM 3 ГБ/ 128 ГБ встроенной памяти/ 3G/ LTE/ GPS/ Nano-SIM/ iOS 10', 25499, '2018-03-10 09:03:10', '2018-03-10 09:03:10', 'Мобильные телефоны'),
	(19, 'Xiaomi Redmi Note 4X 3/32GB Black', 'Экран (5.5", IPS, 1920x1080)/ Qualcomm Snapdragon 625 (2 ГГц)/ основная камера: 13 Мп, фронтальная камера: 5 Мп/ RAM 3 ГБ/ 32 ГБ встроенной памяти + microSD/SDHC (до 128 ГБ)/ 3G/ LTE/ GPS/ GLONASS/ поддержка 2х SIM-карт (Micro-SIM+Nano-SIM)/ Android 6.0 (Marshmallow) / 4100 мА*ч', 4599, '2018-03-10 09:05:08', '2018-03-10 09:05:08', 'Мобильные телефоны'),
	(20, 'Xiaomi Redmi 4A 2/16GB Grey', 'Экран (5", IPS, 1280x720)/ Qualcomm Snapdragon 425 (1.4 ГГц)/ основная камера: 13 Мп, фронтальная камера: 5 Мп/ RAM 2 ГБ/ 16 ГБ встроенной памяти + microSD/SDHC (до 128 ГБ)/ 3G/ GPS/ GLONASS/ поддержка 2х SIM-карт (Micro-SIM+Nano-SIM)/ Android 6.0 (Marshmallow) / 3120 мА*ч', 2799, '2018-03-10 09:06:15', '2018-03-10 09:06:15', 'Мобильные телефоны'),
	(21, 'Xiaomi Redmi 5 3/32GB Black', 'Экран (5.7", IPS, 1440x720)/ Qualcomm Snapdragon 450 (1.8 ГГц)/ основная камера: 12 Мп, фронтальная камера: 5 Мп/ RAM 3 ГБ/ 32 ГБ встроенной памяти + microSD/SDHC (до 128 ГБ)/ 3G/ LTE/ GPS/ GLONASS/ поддержка 2х SIM-карт (Nano-SIM)/ Android 7.0 (Nougat) / 3300 мА*ч', 4799, '2018-03-10 09:10:20', '2018-03-10 09:10:20', 'Мобильные телефоны'),
	(22, 'Xiaomi Redmi 4X 3/32GB Pink', 'Экран (5", IPS, 1280x720)/ Qualcomm Snapdragon 435 (1.4 ГГц)/ основная камера: 13 Мп, фронтальная камера: 5 Мп/ RAM 3 ГБ/ 32 ГБ встроенной памяти + microSD/SDHC (до 128 ГБ)/ 3G/ LTE/ GPS/ GLONASS/ поддержка 2х SIM-карт (Micro-SIM+Nano-SIM)/ Android 6.0 (Marshmallow) / 4100 мА*ч', 4299, '2018-03-10 09:11:26', '2018-03-10 09:11:26', 'Мобильные телефоны'),
	(23, 'Ноутбук Prestigio SmartBook 141C (PSB141C01BFP_BK_CIS) Black', 'Экран 14.1" IPS (1920x1080) Full HD, матовый / Intel Atom x5-Z8350 (1.44 - 1.92 ГГц) / RAM 2 ГБ / eMMC 32 ГБ / Intel HD Graphics 400 / без ОД / Wi-Fi / Bluetooth / веб-камера / Windows 10 Pro / 1.45 кг / черный', 5699, '2018-03-10 09:12:48', '2018-03-10 09:12:48', 'Ноутбук'),
	(24, 'Ноутбук HP ProBook 430 G4 (Y8B46ES)', 'Экран 13.3" (1920x1080) Full HD, матовый / Intel Core i7-7500U (2.7 - 3.5 ГГц) / RAM 8 ГБ / SSD 256 ГБ / Intel HD Graphics 620 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / Windows 10 Pro 64bit / 1.49 кг / серый', 22999, '2018-03-10 09:15:41', '2018-03-10 09:15:41', 'Ноутбук'),
	(25, 'Asus ZenBook UX430UN', 'Экран 14.0" (1920x1080) Full HD, матовый / Intel Core i7-8550U (1.8 - 4.0 ГГц) / RAM 16 ГБ / SSD 512 ГБ / nVidia GeForce MX150, 2 ГБ / без ОД / Wi-Fi / Bluetooth / веб-камера / Windows 10 / 1.3 кг / золотистый / чехол + мышь', 41499, '2018-03-10 09:24:51', '2018-03-10 09:24:51', 'Ноутбук'),
	(26, 'Ноутбук Prestigio SmartBook 116C', 'Экран 11.6" IPS (1920x1080) Full HD, матовый / Intel Atom x5-Z8350 (1.44 - 1.92 ГГц) / RAM 2 ГБ / eMMC 32 ГБ / Intel HD Graphics 400 / без ОД / Wi-Fi / Bluetooth / веб-камера / Windows 10 Pro / 1.06 кг / черный', 5599, '2018-03-10 09:26:47', '2018-03-10 09:26:47', 'Ноутбук'),
	(27, 'Ноутбук Asus ZenBook 3 UX390UA', 'Экран 12.5" IPS (1920x1080) Full HD, глянцевый / Intel Core i7-7500U (2.7 - 3.5 ГГц) / RAM 16 ГБ / SSD 1 ТБ / Intel HD Graphics 620 / без ОД / Wi-Fi / веб-камера / Windows 10 Pro / 910 г / синий / сумка', 34999, '2018-03-10 09:27:52', '2018-03-10 09:27:58', 'Ноутбук'),
	(28, 'Asus Vivobook 14 X405UR', 'Экран 14.0" (1920x1080) Full HD, матовый / Intel Pentium 4405U (2.1 ГГц) / RAM 4 ГБ / HDD 1 ТБ / nVidia GeForce 930MX, 2 ГБ / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / Endless OS / 1.42 кг / красный', 1399, '2018-03-10 09:29:04', '2018-03-10 09:29:04', 'Ноутбук'),
	(29, 'Ноутбук Acer Aspire ES1-132-C64Q', 'Экран 11.6\'\' (1366x768) HD LED, матовый / Intel Celeron N3350 (1.1 - 2.4 ГГц) / RAM 4 ГБ / HDD 500 ГБ / Intel HD Graphics / без ОД / Wi-Fi / Bluetooth / веб-камера / без ОС / 1.2 кг / черный', 7999, '2018-03-10 09:30:55', '2018-03-10 09:30:56', 'Ноутбук'),
	(30, 'Canon EOS 1300D EF-S 18-55mm III + EF 75-300mm f/4-5.6 III USM Kit', 'Матрица 22.3 x 14.9 мм, 18 Мп / Объектив EF-S 18-55mm III + EF 75-300mm f/4-5.6 III USM / Зум: 3.05х (оптический) / поддержка карт памяти SD/SDHC/SDXC / LCD-дисплей 3" / FullHD-видео / Wi-Fi / NFC / питание от литий-ионного аккумулятора / 129 х 147.6 х 101.3 мм, 685 г / черный', 16599, '2018-03-10 09:32:58', '2018-03-10 09:32:59', 'Фотоаппарат'),
	(31, 'Nikon D810 Body (VBA410AE)', 'Матрица 35.9 x 24 мм, 36.3 Мп / поддержка карт памяти SD/SDHC/SDXC/CF тип I / ЖК-дисплей 3.2" / питание от литий-ионного аккумулятора / 146 x 123 x 81.5 мм, 980 г', 89999, '2018-03-10 09:34:18', '2018-03-10 09:34:18', 'Фотоаппарат'),
	(32, 'Canon EOS 200D Kit 18-55 IS STM Black', 'Матрица 22.3 x 14.9 мм, 24.2 Мп / Объектив 18-55mm IS STM / Зум: 0.87х (оптический) / поддержка карт памяти SD/SDHC/SDXC / LCD-дисплей 3" / Full HD-видео / питание от литий-ионного аккумулятора / 122.4 x 92.6 x 69.8 мм, 453 г / черный', 21999, '2018-03-10 09:36:12', '2018-03-10 09:36:12', 'Фотоаппарат'),
	(33, 'Sony Alpha 77M2 Kit 16-50 Black', 'Матрица 23.5 x 15.6 мм, 24.3 Мп / объектив DT 16 - 50 мм F2.8 SSM / Зум: 3.1х (оптический), 4х (цифровой) / поддержка карт памяти Memory Stick PRO Duo, Memory Stick PRO-HG Duo, Memory Stick XC-HG Duo, SD, SDHC, SDXC, microSDHC / поворотный ЖК-экран 3" / FullHD видео / Wi-Fi / NFC / питание от литий-ионного аккумулятора / 142.6 x 168.9 x 104.2 мм, 1303 г / черный', 51999, '2018-03-10 09:37:04', '2018-03-10 09:37:05', 'Фотоаппарат'),
	(35, 'Nikon D610 Body (VBA430AE) ', 'Матрица 35.9 x 24.0 мм, 24.3 Мп / поддержка карт памяти SD/SDHC/SDXC (2 гнезда) / LCD-дисплей 3.2" / FullHD-видео / питание от литий-ионного аккумулятора / 141 x 113 x 82 мм, 850 г', 43999, '2018-03-10 09:41:28', '2018-03-10 09:41:28', 'Фотоаппарат'),
	(36, 'Canon EOS 70D Body', 'Матрица 22.5 x 15 мм, 20.2 Мп / поддержка карт памяти SD/SDHC/SDXC / поворотный сенсорный LCD-дисплей 3" / FullHD-видео / питание от литий-ионного аккумулятора / 139.0 x 104.3 x 78.5 мм, 755 г', 23580, '2018-03-10 09:43:02', '2018-03-10 09:43:02', 'Фотоаппарат');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Дамп структуры для таблица courses.products_camera
DROP TABLE IF EXISTS `products_camera`;
CREATE TABLE IF NOT EXISTS `products_camera` (
  `product_id` int(10) unsigned NOT NULL,
  `quality` decimal(10,0) unsigned NOT NULL,
  KEY `FK_product_camera_products` (`product_id`),
  CONSTRAINT `FK_product_camera_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Дамп данных таблицы courses.products_camera: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `products_camera` DISABLE KEYS */;
REPLACE INTO `products_camera` (`product_id`, `quality`) VALUES
	(15, 12),
	(14, 34),
	(28, 33),
	(23, 23);
/*!40000 ALTER TABLE `products_camera` ENABLE KEYS */;

-- Дамп структуры для таблица courses.products_core
DROP TABLE IF EXISTS `products_core`;
CREATE TABLE IF NOT EXISTS `products_core` (
  `product_id` int(11) unsigned NOT NULL,
  `core_id` int(11) unsigned NOT NULL,
  KEY `FK_product_cores_cores` (`core_id`),
  KEY `FK_product_cores_products` (`product_id`),
  CONSTRAINT `FK_product_cores_cores` FOREIGN KEY (`core_id`) REFERENCES `cores` (`id`),
  CONSTRAINT `FK_product_cores_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Дамп данных таблицы courses.products_core: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `products_core` DISABLE KEYS */;
REPLACE INTO `products_core` (`product_id`, `core_id`) VALUES
	(15, 1),
	(14, 1);
/*!40000 ALTER TABLE `products_core` ENABLE KEYS */;

-- Дамп структуры для таблица courses.products_display
DROP TABLE IF EXISTS `products_display`;
CREATE TABLE IF NOT EXISTS `products_display` (
  `product_id` int(10) unsigned NOT NULL,
  `resolution` varchar(50) NOT NULL,
  `сapacitive` decimal(10,0) unsigned DEFAULT NULL,
  KEY `Индекс 1` (`product_id`),
  CONSTRAINT `FK_products_display_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Дамп данных таблицы courses.products_display: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `products_display` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_display` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
