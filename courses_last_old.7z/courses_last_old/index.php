<?php
/**
 * Created by PhpStorm.
 * User: Andrei
 * Date: 12.04.2018
 * Time: 18:42
 */

interface FigureInterface{
    public function draw();
}

trait FigureTrait{

    protected $data = 10;

    public function processSize($size){
        $this->size +=$size;
        return $this->size;
    }
}

abstract class Figure implements FigureInterface {

    use FigureTrait;
    protected $size;

    public function __construct($size)
    {
        $this->size = $size;
    }

    abstract public function draw();
}

class Circle extends Figure{
    public function draw()
    {
        // TODO: Implement draw() method.
    }
}

class Square extends Figure{
    public function draw()
    {
        // TODO: Implement draw() method.
    }
}

class Triangular extends Figure{
    public function draw()
    {
        // TODO: Implement draw() method.
    }
}

/*$figure = new Circle(5);
echo $figure->processSize(12);*/