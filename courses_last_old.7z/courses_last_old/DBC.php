<?php

include_once 'Cart.php';
include_once 'config.php';
include_once 'product_type/Product.php';
include_once 'product_type/ProductListItem.php';

class DBC
{
    public $db_connect;
    public $mysqli;

    public function __construct()
    {
        $this->MakeConnection();
    }

    private function MakeConnection()
    {
        $param_list = get_DB_param();

        if (!isset($this->db_connect)) {
            $this->db_connect = new mysqli($param_list['host'], $param_list['user'], $param_list['pass'], $param_list['db_name']);
        }
        $this->db_connect;
    }

    public function get_all_product_types()
    {
        $this->MakeConnection();
        $query_text = 'SELECT DISTINCT type FROM products ORDER BY type';

        $stmt = $this->db_connect->prepare($query_text);
        $stmt->execute();

        $result = $stmt->get_result();
        $arr_type_list = [];

        while ($row = $result->fetch_assoc()){
            $arr_type_list[] = $row['type'];
        };

        return $arr_type_list;
    }

    public function bind_params($mysqli_stmt, $params)
    {
        $param_type = '';

        foreach ($params as $_param) {
            if ((int)$_param != 0) {
                $param_type .= 'd';
            } else
                $param_type .= 's';
        }

        $a_param[] = &$param_type;

        $n = count($params);
        for ($i = 0; $i < $n; $i++) {
            $a_param[] = &$params[$i];
        }

        call_user_func_array(array($mysqli_stmt, 'bind_param'), $a_param);
    }

    public function PrepareRequest(&$request_test, &$params){
        $this->mysqli = $this->db_connect->prepare($request_test);
        $this->bind_params($this->mysqli, $params);
    }
}
//*************** SEARCH PRODUCT *********************//

