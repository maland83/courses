<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    include 'User.php';
    User::Register();

}
?>
<form method="post">
    <label for="username">Login:</label><input type="text" id="username" name="username" required><br>
    <label for="email">E-mail:</label><input type="email" id="email" name="email" required><br>
    <label for="password">Password:</label><input type="password" id="password" name="password" required><br>
    <label for="password_confirm">Confirm password:</label><input type="password" id="password_confirm"
                                                                  name="password_confirm" required><br>
    <label for="full_name">Full name:</label><input type="text" id="full_name" name="full_name"><br>
    <input type="submit" value="Register">
</form>