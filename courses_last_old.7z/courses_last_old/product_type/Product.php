<?php

abstract class Product{

    const COUNT_ON_PAGE = 8;

    public $type = '';
    public $price = 0;

    protected $fields;
    protected $joins_str;
    protected $ready_request;
    protected $formElement;
    protected $parentFormElement = [
        'name' => [
            'title' => 'Name',
            'type' => 'text',
            'table' => 'products',
            'field' => 'name',

        ],
        'description' => [
            'title' => 'Description',
            'type' => 'textarea',
            'table' => 'products',
            'field' => 'quality',

        ],
        'price' => [
            'title' => 'Price',
            'type' => 'number',
            'table' => 'products',
            'field' => 'quality',
            'step' => 0.1,
            'min' => 0,
        ],
    ];

    public function __construct($type = '', $prise = 0)
    {
        $this->price = $prise;
        $this->type = $type;

    }

    /**** form for element ****/
    public function GetProductInfo()
    {
        $this->makeRequestText($this->fields_list, $this->joins);
    }

    /**
     * @param $fields_list
     * @param $joins_data
     */
    public function makeRequestText($fields_list, $joins_data)
    {
        $this->prepareFields($fields_list);
        $this->prepareJoins($joins_data);

        $this->query_text = "SELECT $this->fields FROM products $this->joins_str;";
    }

    /**
     * @param $fields_list
     */
    protected function prepareFields($fields_list)
    {
        $columns = [];
        foreach ($fields_list as $table => $items) {
            foreach ($items as $alias => $field) {
                $alias = is_string($alias) ? " AS $alias" : '';
                $columns[] = "$table.$field$alias";
            }
        }

        $this->fields = implode(', ', $columns);
    }
    protected function prepareJoins($joins_data)
    {

        $joins = [];
        foreach ($joins_data as $join) {
            $joins[] = $join['type'] . ' JOIN ' . $join['join_table']
                . ' ON ' . $join['base_table'] . '.' . $join['base_table_key']
                . ' = ' . $join['join_table'] . '.' . $join['join_table_key'];
        }
        $joins_str = implode(' ', $joins);

        $this->joins_str = $joins_str;
    }

    /**
     * @param string $type
     * @return string
     */
    public function buildElementForm($type = 'add')
    {

        $form = '';
        $formElements = $this->parentFormElement + $this->formElement;
        foreach ($formElements as $name => $element) {

            $value = '';
            if ($type == 'edit'){
            $value = $this->resultElement[0][$element['field']];
            }

            $form .= '<p>';
            $form .= '<label for=' . $name . '>' . $element['title'] . '</label>';

            switch ($element['type']) {
                case 'select':

                    $form .= '<select name=' . $name . 'id=' . $name . '>';
                    $form .= $this->getSelectValues($element['values']);
                    $form .= '</select>';
                    $form .= '</br>';
                    $form .= '</p>';
                    break;

                case 'number':

                    $form .= '<input name=' . $name . 'id=' . $name . '"';
                    $form .= isset($element['step']) ? 'step=' . $element['step'] : '';
                    $form .= isset($element['min']) ? 'min=' . $element['min'] : '';
                    $form .= isset($element['max']) ? 'max=' . $element['max'] : '';
                    $form .= '>';
                    $form .= '</br>';
                    $form .= '</p>';
                    break;

                case 'text':

                    $form .= '<input name=' . $name . 'id=' . $name . '"';
                    $form .= '>';
                    $form .= '</br>';
                    $form .= '</p>';
                    break;

                case 'textarea':

                    $form .= '<textarea name=' . $name . 'id=' . $name . '">';
                    $form .= '</textarea>';
                    $form .= '</br>';
                    $form .= '</p>';
                    break;
            }

        }
        return $form;
    }
    public function getSelectValues(array $info, $default_value = NULL)
    {
        $q = 'SELECT ' . $info['value'] . ' as value, ' . $info['title'] . ' as title FROM ' . $info['table'] . ';';

        $mysqli = new mysqli('localhost', 'root', '', 'courses');
        $res = $mysqli->query($q);

        $options = '';

        while ($rows = $res->fetch_assoc()) {
            $options .= '<option value="' . $rows['value'] . '"';
            $options .= ($rows['value'] == $default_value) ? ' selected' : '';
            $options .= '>';
            $options .= $rows['title'];
            $options .= '</option>';

        }
        return $options;
    }
    /*****************************************/

    public static function GetProductList(){

        self::GetSearchForm();

        $cond = [];
        $params = [];
        $with_limit = true;

        if (!empty($_GET['search_string'])){
            $cond[] = ' prod.name LIKE ? ';
            $params[] = '%'.$_GET['search_string'].'%';
        }
        if (!empty($_GET['product_type']) && $_GET['product_type'] != 'all'){
            $cond[] = ' prod.type = ? ';
            $params[] =  $_GET['product_type'];
        }

        $having_request_test = '';

        if (!empty($_GET['only_popular'])){
            $having_request_test = ' HAVING counts > 1';
        }

        $limit_offset_request_test = '';

        if ($with_limit){
            $limit_offset_request_test = self::CountLimitOffset();
        }

        $query_text = 'SELECT prod.name, prod.description, 
                       COUNT(orders.id) AS counts,
                       max(prod.id)  AS prod_id 
                       FROM products AS prod
                       LEFT JOIN 
                       orders AS orders ON orders.product_id = prod.id';

        $cond_text = '';

        if (count($cond)){
            $cond_text = implode(' AND ', $cond);
            $cond_text = ' WHERE ' . $cond_text;
        }

        $query_text .= $cond_text;
        $query_text .= ' GROUP BY prod.id ';
        $query_text .= $having_request_test;
        $query_text .= $limit_offset_request_test;

        $mysqli = new mysqli('localhost', 'root', '', 'courses');
        $stmt = $mysqli->prepare($query_text);
        self::BindParams($stmt, $params);
        $stmt->execute();
        $result = $stmt->get_result();

        $assocResult = $result->fetch_all(MYSQLI_ASSOC);

        echo self::PrepareResultTable($assocResult);
    }
    private static function BindParams($mysqli_stmt, $params){

        if (!count($params)){
            return;
        }

        $param_type = '';

        foreach ($params as $_param){
            if ((int) $_param != 0){
                $param_type  .= 'd';
            }else
                $param_type  .= 's';
        }

        $a_param[] = & $param_type;

        $n = count($params);
        for($i = 0; $i < $n; $i++) {
            $a_param[] = & $params[$i];
        }

        call_user_func_array(array($mysqli_stmt, 'bind_param'), $a_param);
    }
    private static function CountLimitOffset(){

        if (empty($_GET['p'])){
            $offset = 0;
        }else{
            $start_element = ($_GET['p']-1)*self::COUNT_ON_PAGE;
            $offset = $_GET['p']==1?0:$start_element;
        }

        $limit_offset_request_test = ' LIMIT '.self::COUNT_ON_PAGE.' OFFSET '.$offset;
        return $limit_offset_request_test;
    }
    private static function PrepareResultTable(array $assocResult){

        $resultForm = '';
        $resultForm .= '<table border="1">';
        $resultForm .= '<tr>';
        $resultForm .= '<th>Name</th>';
        $resultForm .= '<th>Description</th>';
        $resultForm .= '<th>ID</th>';
        $resultForm .= '</tr>';

        foreach ($assocResult as $elem){
            $resultForm .= '<tr>';
            $resultForm .= '<td>'.$elem['name'].'</td>';
            $resultForm .= '<td>'.$elem['description'].'</td>';
            $resultForm .= '<td><a href='.'/product/view/'.$elem['prod_id'].'>view</a></td>';
            $resultForm .= '<td><a href='.'/product/toCart/?id='.$elem['prod_id'].'>to cart</td>';
            $resultForm .= '</tr>';
        }

        $resultForm .= '</table>';

    return $resultForm;
    }

    //*****************************************//

    private static function GetSearchForm()
    {
        ?>
        <form method="get">
            <label for="search_string">Search:</label>

            <?php
            $search_string_value = '';
            if (!empty($_GET['search_string'])) {
                $search_string_value = $_GET['search_string'];
            }
            ?>

            <input type="text" class="text" id="search_string" value="<?= $search_string_value; ?>"
                   name="search_string">

        <?php

        $checked = '';
        if (!empty($_GET['only_popular'])) {
            $checked = 'checked';
        }
        self::render_select([]);
        ?>

        <div class="checkbox">
            <label>
                Popular: <input type="checkbox" <?= $checked ?> name="only_popular">
            </label>
        </div>

        <button class="btn btn-success" type="submit">Search</button>
        </form>

        <form action="/User.php" method="post">
            <input type="submit" name="LogOut" value="LogOut">
        </form>
        <?php
    }

    private static function render_select($product_types)
    {
        ?>
        <div class="form-group">
            <label for="product_type">Product type:</label>
            <select class="form-control" id="product_type" name="product_type">
                <option value="all">Все</option>
                <?php
                foreach ($product_types as $type => $product_type_value) {
                    if (!empty($_GET['product_type']) && ($_GET['product_type']) == $product_type_value) {
                        echo "<option selected>$product_type_value</option>";
                    } else {
                        echo "<option>$product_type_value</option>";
                    }
                }
                ?>
            </select>
        </div>
        <?php
    }
}
