<?php
/**
 * Created by PhpStorm.
 * User: Andrei
 * Date: 22.03.2018
 * Time: 18:45
 */

class ProductNotebook extends Product
{

    protected $fields_list = [
        'products' => [
            'name',
            'description',
            'price',
        ],
        'cores' => [
            'model',
            'cores',
            'f' => 'frequency',
        ],
    ];

    protected $joins = [
        [
            'type' => 'LEFT',
            'base_table' => 'products',
            'join_table' => 'products_core',
            'base_table_key' => 'id',
            'join_table_key' => 'product_id',
        ],
        [
            'type' => 'INNER',
            'base_table' => 'products_core',
            'join_table' => 'cores',
            'base_table_key' => 'core_id',
            'join_table_key' => 'id',
        ],
    ];


    public function getPrice()
    {
        return $this->price;
    }
}