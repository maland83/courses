<?php

include 'Product.php';
/**
 * Created by PhpStorm.
 * User: Andrei
 * Date: 22.03.2018
 * Time: 18:43
 */

class ProductPhone extends Product
{

    protected $formElement = [
        'core' => [
            'title'  => 'Core',
            'type'   => 'select',
            'table'  => 'product_cote',
            'values' => [
                'table' => 'cores',
                'value' => 'id',
                'title' => 'model'
            ],
            'field'  => 'core_id',
        ],
        'camera' => [
            'title' => 'Camera',
            'type'  => 'number',
            'table' => 'product_camera',
            'field' => 'quality',
            'step'  => 0.1,
            'min'   => 0,
        ],
    ];
    protected $fields_list = [
        'products' => [
            'name',
            'description',
            'price',
            'type',
            'prod_id' => 'id',
        ],
        'cores' => [
            'model',
            'cores',
            'f' => 'frequency',
        ],
    ];
    protected $joins = [
        [
            'type' => 'LEFT',
            'base_table' => 'products',
            'join_table' => 'product_cores',
            'base_table_key' => 'id',
            'join_table_key' => 'product_id',
        ],
        [
            'type' => 'INNER',
            'base_table' => 'product_cores',
            'join_table' => 'cores',
            'base_table_key' => 'core_id',
            'join_table_key' => 'id',
        ],
    ];

    public function getPrice()
    {
        return $this->price;
    }

}