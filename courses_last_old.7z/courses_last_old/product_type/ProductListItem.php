<?php
/**
 * Created by PhpStorm.
 * User: Andrei
 * Date: 25.03.2018
 * Time: 17:39
 */

class ProductListItem
{
    public $name;
    public $description;
    public $price;
    public $type;
    public $prod_id;
}