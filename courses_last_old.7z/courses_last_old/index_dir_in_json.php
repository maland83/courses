<?php
header('content-type:text/html; charset=windows-1251');

$dir = 'D:'.DIRECTORY_SEPARATOR.'OSPanel'.DIRECTORY_SEPARATOR.'domains'.DIRECTORY_SEPARATOR.'courses';
$level = 0;

$summuryArr = [];
scandirectory($dir, $level, $summuryArr);


	$json_str = json_encode($summuryArr);
	echo $json_str;
	echo json_last_error_msg();

function scandirectory($dir, $level, &$summuryArr){

	$dirElements = scandir($dir);
	
	foreach ($dirElements as $key=>$elem){
		
		if ($elem == '.' || $elem == '..'){
			continue;
		}
		
		$fullPath = $dir.DIRECTORY_SEPARATOR.$elem;
			
		if (is_dir($fullPath)) {
			$level++;
			scandirectory($fullPath, $level, $summuryArr);
		}else{
			
			$fileInfo = pathinfo($fullPath);
			$filePath = $fileInfo['dirname'];
			$filePath = iconv('windows-1251','UTF-8', $filePath);
			$summuryArr[$fileInfo['extension']][] = ['path'=> $filePath, 'size' => filesize($fullPath)];			
		}
	}
}