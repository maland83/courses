<?php

class Cart
{
    public static function AddToCart (){

        if (empty($_COOKIE['user_hash'])) {
            $user_hash = random_int(1, 10000);
            setcookie('user_hash', $user_hash);
            $_COOKIE['user_hash'] = $user_hash;
            $_SESSION['user_hash'] = $user_hash;
        }

        //echo 'errorke';
        $user_hash = $_COOKIE['user_hash'];

        $mysqli = new mysqli('localhost', 'root', '', 'courses');

        $query_text = 'SELECT * FROM cart_products WHERE product_id = ? AND anonymous = ?';
        $stmt = $mysqli->prepare($query_text);

        $params = [];
        $params[] = $_GET['id'];
        $params[] = $user_hash;

        self::bind_param($stmt,$params);
        $stmt->execute();
        $res = $stmt->get_result();


        $fetch_res = $res->fetch_all(MYSQLI_ASSOC);

        $count = 0;

        foreach ($fetch_res as $key=>$arr){
            $count += $arr['count'];
        }
        $count +=1;

        $params = [];
        if (count($fetch_res)==0){
            $query_text = 'INSERT INTO cart_products (`product_id`, `user_id`, `anonymous`, `count`) 
                       VALUES (?, ?, ?, ?)';

            $params[] = $_GET['id'];
            $params[] = '0';
            $params[] = $user_hash;
            $params[] = $count == 0?1:$count;

        } else {
            $query_text = 'UPDATE cart_products SET count= ? WHERE product_id = ? AND anonymous = ?';
            $params[] = $count;
            $params[] = $_GET['id'];
            $params[] = $user_hash;

        }

         $stmt = $mysqli->prepare($query_text);

        self::bind_param($stmt,$params);
        $stmt->execute();

        $ss = 0;
    }

    public static function bind_param(&$stmt, &$params){

        $param_type = '';
        foreach ($params as $_param){
            if ( is_numeric($_param)){
                $param_type  .= 'd';
            }else
                $param_type  .= 's';
        }

        $a_param[] = & $param_type;

        $n = count($params);
        for($i = 0; $i < $n; $i++) {
            $a_param[] = & $params[$i];
        }

        call_user_func_array(array($stmt, 'bind_param'), $a_param);

    }

}