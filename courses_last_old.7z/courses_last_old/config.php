<?php
const COUNT_ON_PAGE = 8;

function get_DB_param(){

    $db_conf_host = [
        'user' => 'devinua',
        'pass' => 'itea2018AA',
        'db_name' => 'devinua',
        'host' => 'mysql.zzz.com.ua'];


    $db_conf = [
        'user' => 'root',
        'pass' => '',
        'db_name' => 'courses',
        'host' => 'localhost'];


    if ($_SERVER['HTTP_HOST']=='courses.loc') {
        return $db_conf;
    }else{
        return $db_conf_host;
    }
};
