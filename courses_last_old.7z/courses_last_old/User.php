<?php
include_once 'DBC.php';

if (session_status()!=PHP_SESSION_ACTIVE){
    session_start(['name'=>'super_session']);
}

if ($_SERVER['REQUEST_METHOD']=='POST'){
    if (!empty($_POST['LogOut'])){

        unset($_SESSION['user_id']);
        header('Location:/');
    }
}

class User {

    public static function Register(){

        if ($_POST['password'] != $_POST['password_confirm']) {
            echo 'Пароль та повторный пароль не співпали';
            return;
        }

        $dbc = new DBC();

        $query_text = 'SELECT us.email
                      FROM users AS us WHERE email = ?';

        $params = [$_POST['email']];
        $dbc->PrepareRequest($query_text, $params);

        $dbc->mysqli->execute();
        $res = $dbc->mysqli->get_result();

        if ($res->num_rows != 0) {
            return;
        }
        //*****************************************************************************
        //*****************************************************************************
        $query_text = 'SELECT us.username
                      FROM users AS us WHERE username = ?';

        $params = [$_POST['username']];
        $dbc->PrepareRequest($query_text, $params);

        $dbc->mysqli->execute();
        $res = $dbc->mysqli->get_result();

        if ($res->num_rows != 0) {
            return;
        }
        //*****************************************************************************
        //*****************************************************************************
        $pass_hash = md5($_POST['password']);
        $params = [$_POST['username'],
                        $_POST['email'],
                        $pass_hash,
                        0,
                        $_POST['full_name']];


        $query_text = 'INSERT INTO users (`username`, `email`, `password`, `status`, `full_name`) 
                                      VALUES (?,?,?,?,?)';

        $dbc->PrepareRequest($query_text, $params);

        if ($dbc->mysqli->execute()) {

            $summury_String = $_POST['username'] . $_POST['email'];
            $super_hash = md5($summury_String);
            $full_url = $_SERVER['HTTP_HOST'] . '/user_.php?id=' . $dbc->mysqli->insert_id . '&hash=' . $super_hash;

            mail($_POST['email'], 'Registration', $full_url);
        }
    }

    public static function Confirm(){

        $mysqli = new mysqli('localhost', 'root', '', 'courses');

        $query_text = 'select us.username, us.email, us.status, us.last_access
                      from users as us WHERE id = ?';

        $params = [$_GET['id']];
        $stmt = $mysqli->prepare($query_text);

        bind_param($stmt,$params);

        $stmt->execute();
        $res = $stmt->get_result();
        $fetch_res = $res->fetch_all(MYSQLI_ASSOC);

        $have_err = false;
        if ($fetch_res[0]['last_access'] != '0000-00-00 00:00:00') {
            echo 'Уже активировано!';
            $have_err = true;
        }

        if ($fetch_res[0]['status'] != '0' && $have_err == false) {
            echo 'Уже активировано!';
            $have_err = true;
        }

        if ($have_err) {
            return;
        }

        $super_hash = md5($fetch_res[0]['username'].$fetch_res[0]['email']);

        if ($super_hash == $_GET['hash']){

            $mysqli = new mysqli('localhost', 'root', '', 'courses');
            $query_text = 'UPDATE users SET status = 1 WHERE id = ?';

            $params = [$_GET['id']];
            $stmt = $mysqli->prepare($query_text);

            bind_param($stmt,$params);

            if ($stmt->execute()){
                header('Location:/');
            }

        }

    }

    public static function Login(){
        ?>
        <form method="post">
            <input type="text" name="login">
            <input type="password" name="password">
            <input type="submit" value="Login" name="button">
        </form>

        <form action="Register.php" method="post">
            <input type="submit" value="Registration" name="Registration">
        </form>        <br>

        <?php
        
    }
    public static function Authorization(){
        $_SESSION['user_id'] = '123456';
        header('Location:/');
    }
}