<?php

session_start(['name'=>'super_session']);

include_once 'DBC.php';
include_once 'User.php';


if (empty($_SESSION['user_id'])) {
    if (!empty($_POST['login']) && !empty($_POST['password'])) {
        User::Authorization();
        return;
    } else {
        User::Login();
        return;
    }
}



$product_pattern        = "/product\/view\/[a-z]+\/[0-9]+/";
$product_add_pattern    = "/product\/add/";
$product_edit_pattern   = "/product\/edit\/\?+id=[0-9]+/";
$product_toCart_pattern = "/product\/toCart\/\?+id=[0-9]+/";

if (preg_match($product_pattern, $_SERVER['REQUEST_URI'])) {

    $phone_pattern = '/view\/phone\/[0-9]+/';
    $tablet_pattern = '/view\/tablet\/[0-9]+/';
    $notebook_pattern = '/view\/notebook\/[0-9]+/';
    $camera_pattern = '/view\/camera\/[0-9]+/';

    if (preg_match($phone_pattern, $_SERVER['REQUEST_URI'])) {
        $phone = new ProductPhone();
        $phone->GetProductInfo();
        $result = $phone->ExecuteRequest('ProductPhone');

        $phone->resultElement = $result;
        $phone->buildElementForm();
        $a = '';
        echo $phone->buildElementForm('edit');
    } elseif (preg_match($tablet_pattern, $_SERVER['REQUEST_URI'])) {
        $a = '';
    } elseif (preg_match($notebook_pattern, $_SERVER['REQUEST_URI'])) {
        $a = '';
    } elseif (preg_match($camera_pattern, $_SERVER['REQUEST_URI'])) {
        $a = '';
    };

} elseif (preg_match($product_add_pattern, $_SERVER['REQUEST_URI'])) {
    //add
} elseif (preg_match($product_edit_pattern, $_SERVER['REQUEST_URI'])) {
    //edit
}elseif (preg_match($product_toCart_pattern, $_SERVER['REQUEST_URI'])) {
    Cart::AddToCart();
} else {
    Product::GetProductList();

    /* $product = new Products();
       $product->PrepareSearchForm();
       $product->RenderResultTable($product->ExecuteSearchRequest());*/

}


/*
$my_phone = new ProductPhone();

$my_phone->getProductInfo();

echo $my_phone->buildElementForm('add');
*/
